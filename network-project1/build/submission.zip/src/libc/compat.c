#include <conio.h>
#include <stddef.h>

void *Malloc(size_t n __attribute__ ((unused))) {
    Print("Malloc not implemented in user mode\n");
    return 0;
}
